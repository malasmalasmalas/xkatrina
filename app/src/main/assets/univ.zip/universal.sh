#!/system/bin/sh

# =================================================================
# FUNGSI PEMBANTU (Helper Functions)
# Pemberian Nama
# clean   = Wipe data
# reboot  = Plus Restart
# addon   = Inject prop addon.apk
# samsung = Mengatur prop khusus samsung
# hyperos = Mengatur prop khusus hyperos (redmi, mi, poco)
# vivo    = Mengatur prop khusus vivo (vivo, iqoo)
# eternal = Mengatur prop apk mod eternal/etherum
# nowipe  = Mengatur prop tanpa wipe data target app
# =================================================================

# =================================================================
# SCRIPT PENYIAPAN PERANGKAT (FIXED & COMPATIBLE)
# =================================================================
source /storage/emulated/0/Executor/univ/generate_buildid.sh
source /storage/emulated/0/Executor/univ/generate_vivo.sh
source /storage/emulated/0/Executor/univ/generate_samsung.sh
source /storage/emulated/0/Executor/univ/generate_hyper.sh
source /storage/emulated/0/Executor/univ/functions.sh
source /storage/emulated/0/Executor/univ/generate_prop.sh
source /storage/emulated/0/Executor/univ/generate_fs.sh
source /storage/emulated/0/Executor/univ/generate_addon.sh
source /storage/emulated/0/Executor/univ/generate_eternal.sh
source /storage/emulated/0/Executor/univ/generate_device.sh

# --- 1. KONFIGURASI & IMPORT ---
S_NAME=$(basename "$0")
SCRIPT_NAME=$(echo "$S_NAME" | tr '[:upper:]' '[:lower:]')

TARGET_APP="Tokopedia"
TARGET_PKG="com.tokopedia.tkpd"


FUFUFUSC="RELEASE"
BASE_PATH="/data"

# Jika DEBUG, ubah BASE_PATH dan buat foldernya
if [ "$FUFUFUSC" = "DEBUG" ]; then
    BASE_PATH="/storage/emulated/0/Executor/univ/00"
    
    # Membuat semua folder tujuan sekaligus jika belum ada
    mkdir -p "$BASE_PATH/data" \
             "$BASE_PATH/data/com.tokopedia.tkpd" \
             "$BASE_PATH/adb" \
             "$BASE_PATH/adb/modules" \
             "$BASE_PATH/adb/modules/xkatrina_snstv_prps" \
             "$BASE_PATH/adb/modules/MagiskHidePropsConf" \
             "$BASE_PATH/user" \
             "$BASE_PATH/user/0" \
             "$BASE_PATH/user/0/com.tokopedia.tkpd" \
             "$BASE_PATH/misc" \
             "$BASE_PATH/misc/0000-0000-00000000" \
             "$BASE_PATH/local" \
             "$BASE_PATH/system" \
             "$BASE_PATH/system/users" \
             "$BASE_PATH/system/users/0"
             
    echo "Mode DEBUG: Folder simulasi telah disiapkan."
fi

# Definisi variabel
data_data="$BASE_PATH/data"
data_adb="$BASE_PATH/adb"
data_user="$BASE_PATH/user"
data_misc="$BASE_PATH/misc"
data_local="$BASE_PATH/local"
data_system="$BASE_PATH/system"


TMP_DIR="$data_local/tmp"
mkdir -p "$TMP_DIR" || { echo "Gagal buat TMP_DIR"; exit 1; }

FILE_PROP="$TMP_DIR/system.prop"
FILE_FS="$TMP_DIR/post-fs-data.sh"

XKAT_DIR="$data_adb/modules/xkatrina_snstv_prps/"
MHPC_DIR="$data_adb/modules/MagiskHidePropsConf/"
XKAT_PROP="$data_adb/modules/xkatrina_snstv_prps/system.prop"
MHPC_PROP="$data_adb/modules/MagiskHidePropsConf/system.prop"
XKAT_FS="$data_adb/modules/xkatrina_snstv_prps/post-fs-data.sh"
MHPC_FS="$data_adb/modules/MagiskHidePropsConf/post-fs-data.sh"

AR0="${R}❱${W}"
AR1="${G}❱${W}"
AR2="${G}❱❱${W}"
AR3="❱❱❱"
AR4="${C}❱❱❱❱${W}"
ARW="❱❱❱❱❱❱❱❱❱❱❱"
PRS="${Y}[ PROCESS ]${W}"
RSL="${Y}[ RESULT  ]${W}"
DON="${G}[ DONE    ]${W}"
SKP="${Y}[ SKIP    ]${W}"
ERR="${R}[ ERROR   ]${W}"

# --- 2. DETEKSI OS UNIVERSAL (MENGGUNAKAN GREP AGAR AMAN) ---
if echo "$SCRIPT_NAME" | grep -qi "samsung"; then
    selected_os="samsung"
    fromdata="samfirmware"
    frombrand="SAMSUNG"
    text_os="SAMSUNG"
elif echo "$SCRIPT_NAME" | grep -qi "hyperos"; then
    selected_os="hyper"
    fromdata="mifirmware"
    frombrand="HYPER OS"
    text_os="HYPER"
elif echo "$SCRIPT_NAME" | grep -qi "vivo"; then
    selected_os="vivo"
    fromdata="vifirmware"
    frombrand="VIVO"
    text_os="VIVO"
else
    selected_os=""
    fromdata="randomly"
    frombrand="RANDOM"
    text_os="RANDOM"
fi


# --- 3. LOGIKA EKSEKUSI BERDASARKAN MODE ---

# MODE 1: CLEAN
if echo "$SCRIPT_NAME" | grep -qi "clean"; then
    exe_clean

# MODE 2: ADDON
elif echo "$SCRIPT_NAME" | grep -qi "addon"; then
    exe_addon

# MODE 3: ETERNAL
elif echo "$SCRIPT_NAME" | grep -qi "eternal"; then
    exe_eternal

# MODE 4: DEFAULT (PROSES LENGKAP)
else
    exe_main
fi
