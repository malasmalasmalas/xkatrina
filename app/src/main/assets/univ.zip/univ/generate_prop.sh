#!/system/bin/sh

generate_prop() {
cat <<EOF > "$FILE_PROP"
# This file will be read by resetprop
# MagiskHide Props Config
# Copyright (c) 2018-2021 Didgeridoohan @ XDA Developers
# Licence: MIT

ro.vendor.build.date=$android_date
ro.odm.build.date=$android_date
ro.system.build.date=$android_date
ro.system_ext.build.date=$android_date
ro.product.build.date=$android_date

ro.vendor.build.date.utc=$android_utc
ro.odm.build.date.utc=$android_utc
ro.system.build.date.utc=$android_utc
ro.system_ext.build.date.utc=$android_utc
ro.product.build.date.utc=$android_utc
ro.bootimage.build.date.utc=$android_utc

ro.build.fingerprint=$android_fingerprint
ro.bootimage.build.fingerprint=$android_fingerprint
ro.system.build.fingerprint=$android_fingerprint
ro.vendor.build.fingerprint=$android_fingerprint
ro.product.build.fingerprint=$android_fingerprint
ro.odm.build.fingerprint=$android_fingerprint
ro.system_ext.build.fingerprint=$android_fingerprint

ro.build.description=$android_name-user $android_version $android_buildid $android_incremental release-keys
ro.product.name=$android_name
ro.product.system.name=$android_name
ro.product.vendor.name=$android_name
ro.product.product.name=$android_name
ro.product.odm.name=$android_name
ro.product.system_ext.name=$android_name

ro.product.device=$android_device
ro.product.system.device=$android_device
ro.product.vendor.device=$android_device
ro.product.product.device=$android_device

ro.product.manufacturer=$android_manufacturer
ro.product.system.manufacturer=$android_manufacturer
ro.product.vendor.manufacturer=$android_manufacturer
ro.product.product.manufacturer=$android_manufacturer
ro.product.odm.manufacturer=$android_manufacturer
ro.product.system_ext.manufacturer=$android_manufacturer

ro.product.model=$android_model
ro.product.system.model=$android_model
ro.product.vendor.model=$android_model
ro.product.product.model=$android_model
ro.product.odm.model=$android_model
ro.product.system_ext.model=$android_model

ro.product.brand=$android_brand
ro.product.system.brand=$android_brand
ro.product.vendor.brand=$android_brand
ro.product.product.brand=$android_brand
ro.product.odm.brand=$android_brand
ro.product.system_ext.brand=$android_brand

ro.vendor.build.security_patch=$android_security
ro.build.version.security_patch=$android_security

ro.build.id=$android_buildid

ro.build.version.incremental=$android_incremental

ro.build.user=$android_user

ro.build.host=$android_host

ro.build.version.release=$android_version

ro.build.version.release_or_codename=$android_version

ro.build.display.id=$android_name-user $android_version $android_buildid $android_incremental release-keys

ro.build.flavor=$android_name-user

ro.bootloader=$android_bootloader

ro.build.product=$android_product

ro.product.board=$android_board

ro.build.PDA=$android_incremental

ro.build.changelist=25957887
ro.product_ship=true
ro.build.official.release=true
ro.build.official.developer=false
ro.build.2ndbrand=false
ro.config.rm_preload_enabled=1
ro.build.characteristics=phone
ro.allow.mock.location=0
ro.binary.type=user
ro.build.selinux=1
security.perf_harden=1
ro.build.tags=release-keys
ro.boot.verifiedbootstate=green
ro.boot.veritymode=enforcing
vendor.boot.vbmeta.device_state=locked
ro.build.type=user
ro.debuggable=0
ro.secure=1

EOF

    cp -f "$FILE_PROP" "$XKAT_PROP" > /dev/null 2>&1; 
    cp -f "$FILE_PROP" "$MHPC_PROP" > /dev/null 2>&1; 
}