#!/system/bin/sh

random_ssaid(){

    if is_root; then
        settings delete secure advertising_id >/dev/null 2>&1
        settings delete secure android_id >/dev/null 2>&1
    fi

    FILESSAID="$data_system/users/0/settings_ssaid.xml"
    echo "$PRS Change Android Id"
    installed="$data_data/$TARGET_PKG"
    
    if [ -d "$installed" ]; then
	    if is_root; then
    	    am kill $TARGET_PKG
    	    am force-stop $TARGET_PKG
        fi
        
        NEW_ID=$(rand 'a-f0-9'  16)
        sed -i "/$TARGET_PKG/s/value=\"[^\"]*\"/value=\"$NEW_ID\"/g" "$FILESSAID"
        sed -i "/$TARGET_PKG/s/defaultValue=\"[^\"]*\"/defaultValue=\"$NEW_ID\"/g" "$FILESSAID"
        
        echo "$AR1 $TARGET_PKG : $NEW_ID"
        sleep 0.1
    else
        echo "$AR0 $TARGET_PKG is missing"
        sleep 0.1
    fi

    TARGET_GAPPS="com.android.vending"
    installed="$data_data/$TARGET_GAPPS"
    
    if [ -d "$installed" ]; then
	    if is_root; then
    	    am kill $TARGET_GAPPS
    	    am force-stop $TARGET_GAPPS
        fi
        
        NEW_ID=$(rand 'a-f0-9'  16)
        sed -i "/$TARGET_GAPPS/s/value=\"[^\"]*\"/value=\"$NEW_ID\"/g" "$FILESSAID"
        sed -i "/$TARGET_GAPPS/s/defaultValue=\"[^\"]*\"/defaultValue=\"$NEW_ID\"/g" "$FILESSAID"
        
        echo "$AR1 $TARGET_GAPPS : $NEW_ID"
        sleep 0.1
    else
        echo "$AR0 $TARGET_GAPPS is missing"
        sleep 0.1
    fi

    TARGET_GAPPS="com.google.android.gms"
    installed="$data_data/$TARGET_GAPPS"
    
    if [ -d "$installed" ]; then
	    if is_root; then
    	    am kill $TARGET_GAPPS
    	    am force-stop $TARGET_GAPPS
        fi
        
        NEW_ID=$(rand 'a-f0-9'  16)
        sed -i "/$TARGET_GAPPS/s/value=\"[^\"]*\"/value=\"$NEW_ID\"/g" "$FILESSAID"
        sed -i "/$TARGET_GAPPS/s/defaultValue=\"[^\"]*\"/defaultValue=\"$NEW_ID\"/g" "$FILESSAID"
        
        echo "$AR1 $TARGET_GAPPS : $NEW_ID"
        sleep 0.1
    else
        echo "$AR0 $TARGET_GAPPS is missing"
        sleep 0.1
    fi
}

set_devicename() {
    echo ""
    echo "$PRS  Change Device Name"

    if [[ -z "$phone_name" ]]; then
        echo "$ERR Variabel phone_name kosong."
        return 1
    fi

    local bt_conf="$data_misc/bluedroid/bt_config.conf"
    local bt_bak="$data_misc/bluedroid/bt_config.bak"

    [[ -f "$bt_conf" ]] && sed -i "s|Name = .*|Name = $phone_name|g" "$bt_conf"
    [[ -f "$bt_bak" ]] && sed -i "s|Name = .*|Name = $phone_name|g" "$bt_bak"

    local device_oldname
    device_oldname=$(settings get global device_name)
    settings put global device_name "$phone_name"
    local device_newname
    device_newname=$(settings get global device_name)

    local bluetooth_oldname
    bluetooth_oldname=$(settings get secure bluetooth_name)
    settings put secure bluetooth_name "$phone_name"
    local bluetooth_newname
    bluetooth_newname=$(settings get secure bluetooth_name)

    echo ""
    echo "$AR1 Device    : $device_oldname > $device_newname"
    echo "$AR1 Bluetooth : $bluetooth_oldname > $bluetooth_newname"
    echo ""
}