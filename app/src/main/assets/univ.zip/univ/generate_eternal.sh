#!/system/bin/sh

generate_eternal() {
# Generate random values
this_hserial=$(rand '0-9A-F' 16 | tr '[:upper:]' '[:lower:]')
this_imei1="86$(rand '0-9' 13)"
this_id=$(rand '0-9a-f' 16)
this_adv=$(get_random_adv)

# Prop Value
this_product="$android_product"
this_http="Dalvik/2.1.0 (Linux; U; Android ${android_version}; ${android_model} Build/${android_buildid})"
this_bootloader="$android_incremental"
this_incremental="$android_incremental"
this_fingerprint="$android_fingerprint"
this_radio="$android_incremental.$android_buildid"
this_brand="$android_brand"
this_board="$android_board"
this_user="$android_user"
this_release="$android_version"
this_buildid="$android_buildid"
this_host="$android_host"
this_baseband="$android_incremental"
this_display="$android_name-user $android_version $android_buildid $android_incremental release-keys"
this_manuf="$android_manufacturer"
this_hardware="$android_bootloader"
this_model="$android_model"
this_phonename="$android_model"
this_device="$android_device"

# Random Chrome version (120-145)
chrome_major=$((RANDOM % (145 - 120 + 1) + 120))
chrome_minor=$((RANDOM % 1000))
chrome_patch=$((RANDOM % 100))

# Find eternal_id
ETERNAL_PATH="$data_user/0/$TARGET_PKG/eternal_id"

# Tulis konten XML ke file (tanpa quotes di EOF agar variabel diexpand)
cat > $ETERNAL_PATH << EOF
[
  {
    "BOARD": "$this_board",
    "IDIKLAN": "$this_adv",
    "RADIOVERSION": "$this_radio",
    "HOST": "$this_host",
    "DISPLAY": "$this_display",
    "FINGERPRINT": "$this_fingerprint",
    "BLUETHOOTNAME": "$this_phonename",
    "PRODUCT": "$this_product",
    "SERIAL": "$this_hserial",
    "DEVICENAME": "$this_phonename",
    "ANDROIDID": "$this_id",
    "BUILDID": "$this_buildid",
    "DEVICE": "$this_device",
    "IMEI": "$this_imei1",
    "MODEL": "$this_model",
    "RELEASE": "$this_release",
    "MANUFACTURER": "$this_manuf",
    "USER": "$this_user",
    "BOOT": "$this_bootloader",
    "BRAND": "$this_brand",
    "NAME": "$this_product",
    "HARDWARE": "$this_hardware",
    "SERIAL2": "$this_hserial",
    "HTTPAGENT": "$this_http",
    "INCREMENTAL": "$this_incremental",
    "DESCRIPTION": "$this_product-user $this_release $this_buildid $this_incremental release-keys",
    "USERAGENT": "Mozilla/5.0 (Linux; Android ${this_release}; ${this_model} Build/${this_buildid}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chrome_major}.${chrome_minor}.${chrome_patch} Mobile Safari/537.36",
    "INSTALL": "INSTALL",
    "SDK": "SDK",
    "TIME": "TIME"
  }
]
EOF


if [ -f "$ETERNAL_PATH" ]; then
    # 2. Ambil UID/GID dari folder data aplikasi
    # Kita gunakan stat untuk mengambil pemilik folder aplikasi tersebut
    APP_UID=$(stat -c '%u' "$data_user/0/$TARGET_PKG")
    APP_GID=$(stat -c '%g' "$data_user/0/$TARGET_PKG")

    # 3. Terapkan chown (pemilik) dan chmod (izin akses)
    if [ -n "$APP_UID" ] && [ -n "$APP_GID" ]; then
        chown "$APP_UID:$APP_GID" "$ETERNAL_PATH"
        chmod 660 "$ETERNAL_PATH" # Baca-Tulis untuk Owner & Group
        
        echo ""
        echo "$RSL $APP_UID:$APP_GID "
        echo "$RSL Owner set to $TARGET_PKG"
    else
        echo ""
        echo "$ERR"
    fi
else
    echo ""
    echo "$ERR File not exist"
fi

}