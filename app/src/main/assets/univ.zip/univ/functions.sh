#!/system/bin/sh

# Colours
G='\e[01;32m'    # GREEN
R='\e[01;31m'    # RED
Y='\e[01;33m'    # YELLOW
C='\e[01;36m'    # CYAN
W='\e[01;37m'    # WHITE
N='\e[00;37;40m' # NEUTRAL

# Cek Root
is_root() {
    # Perintah 'id -u' akan menghasilkan 0 jika user adalah root
    if [ "$(id -u)" -eq 0 ]; then
        return 0 # True (Root)
    else
        return 1 # False (Non-Root)
    fi
}

# Mode pesawat
modepes() {
    if is_root; then
        # Mencoba menjalankan perintah settings
        settings put global airplane_mode_on "$1"
        am broadcast -a android.intent.action.AIRPLANE_MODE
    fi
}

# Fungsi untuk mengambil model samsung acak dari array
get_random_model_samsung() {
    local random_index=$((RANDOM % ${#modelsamsung[@]}))
    echo "${modelsamsung[$random_index]}"
}

# Fungsi untuk mengambil model hyperos acak dari array
get_random_model_hyper() {
    local random_index=$((RANDOM % ${#modelhyper[@]}))
    echo "${modelhyper[$random_index]}"
}

# Fungsi untuk mengambil model vivo acak dari array
get_random_model_vivo() {
    local random_index=$((RANDOM % ${#modelvivo[@]}))
    echo "${modelvivo[$random_index]}"
}

get_random_androidbuild() {
    local random_index=$((RANDOM % ${#androidbuild[@]}))
    echo "${androidbuild[$random_index]}"
}

get_random_month() {
    case $((RANDOM % 12)) in
        0) echo "Jan";; 1) echo "Feb";; 2) echo "Mar";;
        3) echo "Apr";; 4) echo "May";; 5) echo "Jun";;
        6) echo "Jul";; 7) echo "Aug";; 8) echo "Sep";;
        9) echo "Oct";; 10) echo "Nov";; 11) echo "Dec";;
    esac
}

# Kernel version string: "#1 N Mon DD TZ YYYY"
get_random_kernelver() {
    random_numb=$(tr -dc '1-9' < /dev/urandom | head -c 1)
    random_day=$((RANDOM % 28 + 1))
    random_year=$((RANDOM % 5 + 2020))

    case $((RANDOM % 12)) in
        0) m="Jan";; 1) m="Feb";; 2) m="Mar";;
        3) m="Apr";; 4) m="May";; 5) m="Jun";;
        6) m="Jul";; 7) m="Aug";; 8) m="Sep";;
        9) m="Oct";; 10) m="Nov";; 11) m="Dec";;
    esac

    case $((RANDOM % 5)) in
        0) tz="KST";; 1) tz="PST";; 2) tz="EST";;
        3) tz="UTC";; 4) tz="GMT";;
    esac

    echo "#1 $random_numb $m $random_day $tz $random_year"
}

# Kernel version: "5.4.123-android14-12345678-ab"
get_random_kernel() {
    case $((RANDOM % 2)) in
        0) f0="5";; 1) f0="6";;
    esac
    f1=$(tr -dc '1-9' < /dev/urandom | head -c 1)
    f2=$(tr -dc '1-9' < /dev/urandom | head -c 3)
    aos=$(tr -dc '1-6' < /dev/urandom | head -c 1)
    h0=$(tr -dc '1-9' < /dev/urandom | head -c 1)
    h1=$(tr -dc '0-9' < /dev/urandom | head -c 7)
    h2=$(tr -dc 'a-z' < /dev/urandom | head -c 2)

    echo "${f0}.${f1}.${f2}-android1${aos}-${h0}${h1}-${h2}"
}

# Nama operator Indonesia secara acak
get_random_operator() {
    case $((RANDOM % 5)) in
        0) echo "PT Telkomsel";;
        1) echo "PT Indosat Ooredoo";;
        2) echo "PT XL Axiata";;
        3) echo "PT Smartfren Telecom Tbk";;
        4) echo "PT Hutchison 3 Indonesia";;
    esac
}

# Id Iklan secara acak
get_random_adv() {
    p1=$(tr -dc 'a-f0-9' < /dev/urandom | head -c 8)
    p2=$(tr -dc 'a-f0-9' < /dev/urandom | head -c 4)
    p3=$(tr -dc 'a-f0-9' < /dev/urandom | head -c 4)
    p4=$(tr -dc 'a-f0-9' < /dev/urandom | head -c 4)
    p5=$(tr -dc 'a-f0-9' < /dev/urandom | head -c 12)
    echo "${p1}-${p2}-${p3}-${p4}-${p5}"
}

# Fungsi untuk generate random string
rand() {
    local chars="$1"
    local length="$2"
    tr -dc "$chars" < /dev/urandom | head -c "$length"
}

# Fungsi untuk memecah string
split_string() {
    local string="$1"
    IFS='|' read -r phone_name android_brand android_model android_name android_device <<< "$string"
    
    echo "$AR1 Phone Name   : $phone_name"
    sleep 0.1
    echo "$AR1 Brand        : $android_brand"
    sleep 0.1
    echo "$AR1 Manufacturer : $android_manufacturer"
    sleep 0.1
    echo "$AR1 Model        : $android_model"
    sleep 0.1
    echo "$AR1 Device       : $android_device"
    sleep 0.1
    echo "$AR1 Name         : $android_name"
    sleep 0.1

    android_user="$(rand 'BCDFGHJKLMNPQRSTVWXYZ' 1)$(rand 'aeiou' 1)$(rand 'bcdfghjklmnpqrstvwxyz' 1)$(rand 'aeiou' 1)$(rand 'bcdfghjklmnpqrstvwxyz' 1)$(rand 'aeiou' 1)"
    android_host="$(rand 'a-z' 3)$(rand '0-9' 2)-$(rand 'a-z' 3)$(rand '0-9' 2)-$(rand 'a-z' 2)$(rand '0-9' 3)"
    android_utc="166943$(rand '0-9' 4)"
    android_date="$(date '+%a %b %d %H:%M:%S %Z %Y' || echo 'Mon Jan 01 00:00:00 UTC 2023')"
    android_security="$(date '+%Y-%m-01' || echo '2023-01-01')"
    android_bootloader=$(rand 'A-Z' 6)$(rand '0123' 1)$(rand 'AUIEO' 2)
    android_product=$android_device$(rand 'a-z' 2)
    android_board=$(rand 'BCDFGHJKLMNPQRSTVWXYZ' 1)$(rand 'aUiEo' 2)$(rand 'bcdfghjklmopqrstvwxyz' 1)$(rand 'auieo' 1)$(rand 'BCDFGHJKLMNPQRSTVWXYZ' 1)$(rand '0123' 1)$(rand 'AuIeO' 2)
}

# Mengambil data
get_data() {
    local data_type="$1"
    
    if echo "$data_type" | grep -qi "samsung"; then
        random_model=$(get_random_model_samsung)
        android_manufacturer="samsung"
    elif echo "$data_type" | grep -qi "hyper"; then
        random_model=$(get_random_model_hyper)
        android_manufacturer="Xiaomi"
    elif echo "$data_type" | grep -qi "vivo"; then
        random_model=$(get_random_model_vivo)
        android_manufacturer="vivo"
    else
        # Versi dengan 3 opsi (Samsung, Hyper, Vivo)
        random_choice=$((RANDOM % 3))
        if [ $random_choice -eq 0 ]; then
            random_model=$(get_random_model_samsung)
            android_manufacturer="samsung"
        elif [ $random_choice -eq 1 ]; then
            random_model=$(get_random_model_hyper)
            android_manufacturer="Xiaomi"
        else
            random_model=$(get_random_model_vivo)
            android_manufacturer="vivo"
        fi
    fi
    
    android_manufacturer_upper=$(echo "$android_manufacturer" | tr '[:lower:]' '[:upper:]')
    echo "$PRS Selected    $AR1 $android_manufacturer_upper"
    echo "$AR1 $random_model"
    sleep 0.1
    echo ""
    echo "$PRS Split       $AR1 $android_manufacturer_upper"
    sleep 0.1
    split_string "$random_model"
    
    # Ekstrak model dari model random
    model=$(echo "$random_model" | cut -d'|' -f2)
    
    # Dapatkan 1 incremental random berdasarkan model
    echo ""
    echo "$PRS Incremental $AR1 $android_model :"

    if echo "$android_manufacturer" | grep -qi "samsung"; then
        random_incremental=$(get_random_incremental_samsung "$android_model")
    elif echo "$android_manufacturer" | grep -qi "Xiaomi"; then
        random_incremental=$(get_random_incremental_hyper "$android_model")
    elif echo "$android_manufacturer" | grep -qi "vivo"; then
        random_incremental=$(get_random_incremental_vivo "$android_model")
    else
        echo "ERROR"
        exit 1
    fi

    sleep 0.1
    
    if [[ "$random_incremental" != "ERROR" ]]; then
        IFS='|' read -r android_incremental android_version <<< "$random_incremental"
        echo "$AR1 Incremental  : $android_incremental"
        sleep 0.1
        echo "$AR1 Android      : $android_version"
        sleep 0.1
    else
        echo "WARNING"
        echo "Tidak ada data incremental untuk model: $android_model"
        exit 1
    fi
    
    echo ""
    echo "$PRS Build ID    $AR1 $android_model :"
    sleep 0.1
    android_buildid=$(get_random_androidbuild)
    echo "$AR1 Build        : $android_buildid"
    sleep 0.1
    echo ""
    echo "$PRS Fingerprint $AR1 $android_model :"
    sleep 0.1
    android_fingerprint="$android_brand/$android_name/$android_device:$android_version/$android_buildid/$android_incremental:user/release_keys"
    echo "$AR1 Fingerprint  : $android_brand/$android_name/$android_device:$android_version/"
    echo "                 $android_buildid/$android_incremental:"
    echo "                 user/release_keys"
    sleep 0.1
    echo ""
    echo "$PRS Additional  $AR1 $android_model :"
    sleep 0.1
    echo "$AR1 Bootloader   : $android_bootloader"
    sleep 0.1
    echo "$AR1 Product      : $android_product"
    sleep 0.1
    echo "$AR1 Board        : $android_board"
    sleep 0.1
    echo "$AR1 User         : $android_user"
    sleep 0.1
    echo "$AR1 Host         : $android_host"
    sleep 0.1
    echo "$AR1 Utc          : $android_utc"
    sleep 0.1
    echo "$AR1 Date         : $android_date"
    sleep 0.1
    echo "$AR1 Security     : $android_security"
    sleep 0.1
}

# Fungsi untuk menampilkan banner
show_banner_clean() {
    echo "═════════════════════════════════════════════════"
    echo "$AR4 WIPE DATA $TARGET_APP"
    echo "══════════════════════"
    echo ""
}

show_banner_eternal() {
    echo "═════════════════════════════════════════════════"
    echo "$AR4 ETERNAL INJECTION ${Y}$text_os${W}"
    echo "══════════════════════"
    echo ""
}

show_banner_addon() {
    echo "═════════════════════════════════════════════════"
    echo "$AR4 ADDON INJECTION ${Y}$text_os${W}"
    echo "══════════════════════"
    echo ""
}

show_banner_status() {
# Cek apakah direktori exist
    xkat_exist=0
    mhpc_exist=0
    
    if [ -d "$XKAT_DIR" ]; then
        xkat_exist=1
    fi
    
    if [ -d "$MHPC_DIR" ]; then
        mhpc_exist=1
    fi

    if [ $xkat_exist -eq 1 ] && [ $mhpc_exist -eq 1 ]; then
        echo "═════════════════════════════════════════════════"
        echo "$AR4 MHPC - XKAT ACTIVE ${Y}$text_os${W}"
        echo "══════════════════════"
        echo ""
        echo "$AR4 WARNING: Kedua module aktif!"
        echo "$AR1 xkatrina_snstv_prps: AKTIF"
        echo "$AR1 MagiskHidePropsConf: AKTIF"
        
    elif [ $xkat_exist -eq 1 ]; then
        echo "═════════════════════════════════════════════════"
        echo "$AR4 XKAT ACTIVE ${Y}$text_os${W}"
        echo "══════════════════════"
        echo ""
        echo "$AR1 xkatrina_snstv_prps: AKTIF"
        echo "$AR0 MagiskHidePropsConf: TIDAK AKTIF"
        
    elif [ $mhpc_exist -eq 1 ]; then
        echo "═════════════════════════════════════════════════"
        echo "$AR4 MHPC ACTIVE ${Y}$text_os${W}"
        echo "══════════════════════"
        echo ""
        echo "$AR0 xkatrina_snstv_prps: TIDAK AKTIF"
        echo "$AR1 MagiskHidePropsConf: AKTIF"
        
    else
        echo "═════════════════════════════════════════════════"
        echo "$AR4 MODULE INACTIVE"
        echo "══════════════════════"
        echo ""
        echo "$AR0 xkatrina_snstv_prps: TIDAK AKTIF"
        echo "$AR0 MagiskHidePropsConf: TIDAK AKTIF"
        exit 1
    fi

    echo ""
}

# Force-stop & clear aplikasi
wipe_data() {
echo "$PRS Stop and Clean app..."
if echo "$SCRIPT_NAME" | grep -qi "nowipe"; then
    echo "$SKP Non Wipe Data $TARGET_APP"
    TARGET_PKG="non.wipe.data.target"
fi

apps_to_stop_clear=(
$TARGET_PKG
com.android.chrome
com.android.location.fused
com.google.android.gms
com.google.android.gsf
com.android.vending
android.ext.services
android.ext.shared
)

for app in "${apps_to_stop_clear[@]}"; do
    fs_status="$AR1"
    wipe_status="$AR1"
    
    # Check force-stop status
    if ! su -c "am force-stop '$app'" > /dev/null 2>&1; then
        fs_status="$AR0"
    fi
    
    # Check wipe status
    if ! su -c "pm clear '$app'" > /dev/null 2>&1; then
        wipe_status="$AR0"
    fi
    
    echo "$fs_status Force | $wipe_status Wipe : $app"
done

echo ""
echo "$PRS Clean file and cache..."

# Hapus file / cache
paths_to_clean=(
"/storage/emulated/0/.*"
"/storage/emulated/0/.mixplorer"
"/storage/emulated/0/Android/*"
"$data_data/com.android.location.fused/*"
"$data_data/com.google.android.gms/*"
"$data_data/com.google.android.gsf/*"
"$data_user/0/$TARGET_PKG/*"
"$data_data/android.ext.services/*"
"$data_data/android.ext.shared/*"
"$data_local/*"
"/storage/emulated/0/Pictures/*"
"/storage/emulated/0/.cri"
"/storage/emulated/0/LOST.DIR/*"
)

for path in "${paths_to_clean[@]}"; do
    if su -c "rm -rf '$path'" > /dev/null 2>&1; then
        clean_path="${path#$BASE_PATH/}"
        clean_path="${clean_path#/storage/emulated/0/}"
        echo "$AR1 Clean : $clean_path"
    else
        clean_path="${path#$BASE_PATH/}"
        clean_path="${clean_path#/storage/emulated/0/}"
        echo "$AR0 Gagal Clean : $clean_path"
    fi
done

echo ""
echo "$PRS Menghapus folder kosong..."
if su -c "find /storage/emulated/0/ -type d -empty -delete" > /dev/null 2>&1; then
    echo "$AR1 Folder kosong dihapus"
else
    echo "$AR0 Gagal hapus folder kosong"
fi

echo ""
echo "$DON Proses selesai!"
}

exe_clean() {
    show_banner_clean
    random_ssaid
    echo ""
    wipe_data

    if echo "$SCRIPT_NAME" | grep -qi "reboot"; then
       reboot
    fi

    exit
}

exe_addon() {
    if is_root; then
        am kill com.fufufu.katrina.addon
        am force-stop com.fufufu.katrina.addon
    fi
    modepes "1"
    show_banner_addon
    get_data "$selected_os"
    generate_addon
    sleep 2
    echo ""
    echo "$DON ADDON SUKSES"
    sleep 1
    if is_root; then
        am start -n com.fufufu.katrina.addon/com.fufufu.katrina.addon.MainActivity
    fi
    echo ""
    echo "Auto close on 5 seconds"
    sleep 5
    exit
}

exe_eternal() {
    show_banner_eternal
    get_data "$selected_os"
    generate_eternal
    sleep 2
    echo ""
    echo "$DON ETERNAL SUKSES"
    echo ""
    echo "Auto close on 5 seconds"
    sleep 5
    exit
}

exe_main() {
    modepes "1"
    show_banner_status
    get_data "$selected_os"
    generate_prop
    generate_fs
    sleep 2
    #clear

    show_banner_status
    random_ssaid
    set_devicename
    sleep 2
    #clear

    show_banner_status
    wipe_data
    sleep 2
    #clear

    show_banner_status
    echo "Restart..."
    sleep 2
    if is_root; then
        reboot
    fi
}