#!/system/bin/sh

generate_addon() {
# Generate random values
this_simsub=$(rand '0-9' 15)
this_gsf=$(rand '0-9A-F' 16 | tr '[:lower:]' '[:upper:]')
this_mobno="628$(rand '12356789' 1)$(rand '123456789' 1)$(rand '0-9' 8)"
this_bmac=$(printf "%02X:%02X:%02X:%02X:%02X:%02X" $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)))
this_wbssid=$(printf "%02X:%02X:%02X:%02X:%02X:%02X" $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)))
this_wmac=$(printf "%02X:%02X:%02X:%02X:%02X:%02X" $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)))
this_wssid=$(rand 'a-zA-Z0-9' 12)
this_hserial=$(rand '0-9A-F' 16 | tr '[:upper:]' '[:lower:]')
this_simserial=$(rand '0-9' 15)
this_operatormcc="510$(printf "%02d" $((RANDOM % 99)))"
this_imei1="86$(rand '0-9' 13)"
this_drm=$(rand 'a-zA-Z0-9+/=' 40)
this_id=$(rand '0-9a-f' 16)
this_imei2="86$(rand '0-9' 13)"
this_kernelver=$(get_random_kernelver)
this_kernel=$(get_random_kernel)
this_operatorname=$(get_random_operator)
this_adv=$(get_random_adv)

# Prop Value
this_product="$android_product"
this_http="Dalvik/2.1.0 (Linux; U; Android $android_version; $android_model Build/$android_buildid)"
this_bootloader="$android_incremental"
this_incremental="$android_incremental"
this_fingerprint="$android_fingerprint"
this_radio="$android_incremental.$android_buildid"
this_brand="$android_brand"
this_board="$android_board"
this_user="$android_user"
this_release="$android_version"
this_buildid="$android_buildid"
this_host="$android_host"
this_baseband="$android_incremental"
this_display="$android_name-user $android_version $android_buildid $android_incremental release-keys"
this_manuf="$android_manufacturer"
this_hardware="$android_bootloader"
this_model="$android_model"
this_phonename="$android_model"
this_device="$android_device"

# Find fufufu_id.xml
XML_PATH=$(find $data_misc/*-*/ -name "fufufu_id.xml" -type f 2>/dev/null | head -1)
if [[ -z "$XML_PATH" ]]; then
    echo ""
    echo "$ERR fufufu_id.xml tidak ditemukan."
    exit 1
fi

# Tulis konten XML ke file (tanpa quotes di EOF agar variabel diexpand)
cat > $XML_PATH << EOF
<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <boolean name="bmac" value="true" />
    <boolean name="release" value="true" />
    <boolean name="operator" value="true" />
    <boolean name="radio" value="true" />
    <boolean name="host" value="true" />
    <boolean name="fingerprint" value="true" />
    <boolean name="model" value="true" />
    <boolean name="id" value="true" />
    <boolean name="brand" value="true" />
    <boolean name="drm" value="true" />
    <boolean name="hardware" value="true" />
    <boolean name="simserial" value="true" />
    <boolean name="wssid" value="true" />
    <boolean name="simsub" value="true" />
    <boolean name="adv" value="true" />
    <boolean name="http" value="true" />
    <boolean name="device" value="true" />
    <boolean name="manuf" value="true" />
    <boolean name="buildid" value="true" />
    <boolean name="wmac" value="true" />
    <boolean name="phonename" value="true" />
    <boolean name="hserial" value="true" />
    <boolean name="bootloader" value="true" />
    <boolean name="product" value="true" />
    <boolean name="kernel" value="true" />
    <boolean name="display" value="true" />
    <boolean name="incremental" value="true" />
    <boolean name="baseband" value="true" />
    <boolean name="wbssid" value="true" />
    <boolean name="mobno" value="true" />
    <boolean name="imei" value="true" />
    <boolean name="gsf" value="true" />
    <boolean name="user" value="true" />
    <boolean name="board" value="true" />
    <string name="lock_mnf">RANDOM</string>
    <string name="lock_id">Indonesia</string>
    <string name="operatorcountry_val">Indonesia</string>
    <string name="simsub_val">$this_simsub</string>
    <string name="gsf_val">$this_gsf</string>
    <string name="imei1_val">$this_imei1</string>
    <string name="adv_val">$this_adv</string>
    <string name="drm_val">$this_drm</string>
    <string name="imei2_val">$this_imei2</string>
    <string name="kernel_val">$this_kernel</string>
    <string name="mobno_val">$this_mobno</string>
    <string name="bmac_val">$this_bmac</string>
    <string name="wbssid_val">$this_wbssid</string>
    <string name="wssid_val">$this_wssid</string>
    <string name="hserial_val">$this_hserial</string>
    <string name="simserial_val">$this_simserial</string>
    <string name="operatorname_val">$this_operatorname</string>
    <string name="wmac_val">$this_wmac</string>
    <string name="kernelver_val">$this_kernelver</string>
    <string name="operatormcc_val">$this_operatormcc</string>
    <string name="product_val">$this_product</string>
    <string name="http_val">$this_http</string>
    <string name="bootloader_val">$this_bootloader</string>
    <string name="incremental_val">$this_incremental</string>
    <string name="radio_val">$this_radio</string>
    <string name="user_val">$this_user</string>
    <string name="release_val">$this_release</string>
    <string name="buildid_val">$this_buildid</string>
    <string name="host_val">$this_host</string>
    <string name="baseband_val">$this_baseband</string>
    <string name="display_val">$this_display</string>
    <string name="hardware_val">$this_hardware</string>
    <string name="model_val">$this_model</string>
    <string name="id_val">$this_id</string>
    <string name="manuf_val">$this_manuf</string>
    <string name="phonename_val">$this_phonename</string>
    <string name="fingerprint_val">$this_fingerprint</string>
    <string name="device_val">$this_device</string>
    <string name="brand_val">$this_brand</string>
    <string name="board_val">$this_board</string>
</map>
EOF

}
