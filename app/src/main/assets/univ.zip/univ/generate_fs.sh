#!/system/bin/sh

generate_fs(){
cat <<EOF > "$FILE_FS"
#!/system/bin/sh

MODDIR="\${0%/*}"
MODNAME="\${MODDIR##*/}"
MAGISKTMP="\$(magisk --path)" || MAGISKTMP=/sbin

if [ "\$(magisk -V)" -lt 26302 ] || [ "\$("/data/adb/ksud" -V)" -lt 10818 ]; then
  touch "\$MODDIR/disable"
fi

if [ ! -e "\$MAGISKTMP/.magisk/mirror/sepolicy.rules/\$MODNAME/sepolicy.rule" ] && [ ! -e "\$MAGISKTMP/.magisk/sepolicy.rules/\$MODNAME/sepolicy.rule" ]; then
    magiskpolicy --live --apply "\$MODDIR/sepolicy.rule"
    ksud sepolicy apply "\$MODDIR/sepolicy.rule"
fi

ksud sepolicy apply "\$MODDIR/sepolicy.rule"

. "\$MODDIR/resetprop.sh"

# these props must be set in post-fs-data
# clear out lineage and aosp words
# replace:
#    userdebug -> user
#    test-keys -> release-keys

#XKatrina
#
check_resetprop ro.bootimage.build.date $android_date
check_resetprop ro.build.date $android_date
check_resetprop ro.ceos.build.date $android_date
check_resetprop ro.odm.build.date $android_date
check_resetprop ro.product.build.date $android_date
check_resetprop ro.system.build.date $android_date
check_resetprop ro.system_ext.build.date $android_date
check_resetprop ro.vendor.build.date $android_date


check_resetprop ro.bootimage.build.date.utc $android_utc
check_resetprop ro.build.date.utc $android_utc
check_resetprop ro.odm.build.date.utc $android_utc
check_resetprop ro.product.build.date.utc $android_utc
check_resetprop ro.system.build.date.utc $android_utc
check_resetprop ro.vendor.build.date.utc $android_utc
check_resetprop ro.system_ext.build.date.utc $android_utc
check_resetprop ro.build.date.utc $android_utc


check_resetprop ro.bootimage.build.fingerprint $android_fingerprint
check_resetprop ro.build.fingerprint $android_fingerprint
check_resetprop ro.odm.build.fingerprint $android_fingerprint
check_resetprop ro.product.build.fingerprint $android_fingerprint
check_resetprop ro.system.build.fingerprint $android_fingerprint
check_resetprop ro.system_ext.build.fingerprint $android_fingerprint
check_resetprop ro.vendor.build.fingerprint $android_fingerprint

check_resetprop ro.product.model $android_model
check_resetprop ro.product.odm.model $android_model
check_resetprop ro.product.product.model $android_model
check_resetprop ro.product.system.model $android_model
check_resetprop ro.product.system_ext.model $android_model
check_resetprop ro.product.vendor.model $android_model


check_resetprop ro.product.brand $android_brand
check_resetprop ro.product.system_ext.brand $android_brand
check_resetprop ro.product.vendor.brand $android_brand
check_resetprop ro.product.product.brand $android_brand
check_resetprop ro.product.system.brand $android_brand
check_resetprop ro.product.odm.brand $android_brand

check_resetprop ro.product.manufacturer $android_manufacturer
check_resetprop ro.product.odm.manufacturer $android_manufacturer
check_resetprop ro.product.system.manufacturer $android_manufacturer
check_resetprop ro.product.product.manufacturer $android_manufacturer
check_resetprop ro.product.system_ext.manufacturer $android_manufacturer
check_resetprop ro.product.vendor.manufacturer $android_manufacturer

check_resetprop ro.product.name $android_name
check_resetprop ro.product.product.name $android_name
check_resetprop ro.product.odm.name $android_name
check_resetprop ro.product.system.name $android_name
check_resetprop ro.product.system_ext.name $android_name
check_resetprop ro.product.vendor.name $android_name

check_resetprop ro.ceos.device $android_device
check_resetprop ro.product.device $android_device
check_resetprop ro.product.odm.device $android_device
check_resetprop ro.product.system.device $android_device
check_resetprop ro.product.product.device $android_device
check_resetprop ro.product.vendor.device $android_device
check_resetprop ro.product.system_ext.device $android_device

check_resetprop ro.build.official.release $android_version
check_resetprop ro.build.version.release $android_version
check_resetprop ro.odm.build.version.release $android_version
check_resetprop ro.product.build.version.release $android_version
check_resetprop ro.system.build.version.release $android_version
check_resetprop ro.system_ext.build.version.release $android_version
check_resetprop ro.vendor.build.version.release $android_version

check_resetprop ro.vendor.build.id $android_buildid
check_resetprop ro.system_ext.build.id $android_buildid
check_resetprop ro.system.build.id $android_buildid
check_resetprop ro.product.build.id $android_buildid
check_resetprop ro.odm.build.id $android_buildid
check_resetprop ro.build.id $android_buildid

check_resetprop ro.bootloader $android_incremental
check_resetprop ro.odm.build.version.incremental $android_incremental
check_resetprop ro.product.build.version.incremental $android_incremental
check_resetprop ro.system.build.version.incremental $android_incremental
check_resetprop ro.system_ext.build.version.incremental $android_incremental
check_resetprop ro.vendor.build.version.incremental $android_incremental
check_resetprop ro.build.version.incremental $android_incremental

check_resetprop ro.build.version.security_patch $android_security
check_resetprop ro.vendor.build.security_patch $android_security

check_resetprop ro.build.product $android_product

check_resetprop ro.build.description $android_name-user $android_version $android_buildid $android_incremental release-keys

check_resetprop ro.build.displayid $android_name-user $android_version $android_buildid $android_incremental release-keys

check_resetprop ro.build.host $android_host

check_resetprop ro.build.user $android_user

check_resetprop ro.product.board $android_board

check_resetprop ro.hardware $android_bootloader

check_resetprop ro.build.changelist 25957887
check_resetprop ro.product_ship true
check_resetprop ro.build.official.release true
check_resetprop ro.build.official.developer false
check_resetprop ro.build.2ndbrand false
check_resetprop ro.config.rm_preload_enabled 1
check_resetprop ro.build.characteristics phone
check_resetprop ro.allow.mock.location 0
check_resetprop ro.binary.type user
check_resetprop ro.build.selinux 1
check_resetprop security.perf_harden 1
check_resetprop ro.build.tags release-keys
check_resetprop ro.boot.verifiedbootstate green
check_resetprop ro.boot.veritymode enforcing
check_resetprop vendor.boot.vbmeta.device_state locked
check_resetprop ro.build.type user
check_resetprop ro.debuggable 0
check_resetprop ro.secure 1

# Fix Lineage and Debugging props
replace_value_resetprop ro.build.description "aosp_" ""
replace_value_resetprop ro.build.fingerprint "aosp_" ""
replace_value_resetprop ro.build.flavor "aosp_" ""
replace_value_resetprop ro.product.bootimage.name "aosp_" ""
replace_value_resetprop ro.product.name "aosp_" ""

replace_value_resetprop ro.build.description "lineage_" ""
replace_value_resetprop ro.build.fingerprint "lineage_" ""
replace_value_resetprop ro.build.flavor "lineage_" ""
replace_value_resetprop ro.product.bootimage.name "lineage_" ""
replace_value_resetprop ro.product.name "lineage_" ""

replace_value_resetprop ro.build.description test-keys release-keys
replace_value_resetprop ro.build.description userdebug user
replace_value_resetprop ro.build.fingerprint test-keys release-keys
replace_value_resetprop ro.build.fingerprint userdebug user
replace_value_resetprop ro.build.flavor userdebug user

for prefix in system vendor system_ext product oem odm vendor_dlkm odm_dlkm bootimage; do
    check_resetprop ro.\${prefix}.build.tags release-keys
    check_resetprop ro.\${prefix}.build.type user
    replace_value_resetprop ro.\${prefix}.build.description test-keys release-keys
    replace_value_resetprop ro.\${prefix}.build.description userdebug user
    replace_value_resetprop ro.\${prefix}.build.fingerprint test-keys release-keys
    replace_value_resetprop ro.\${prefix}.build.fingerprint userdebug user
    replace_value_resetprop ro.\${prefix}.build.description "aosp_" ""
    replace_value_resetprop ro.\${prefix}.build.fingerprint "aosp_" ""
    replace_value_resetprop ro.product.\${prefix}.name "aosp_" ""
    replace_value_resetprop ro.\${prefix}.build.description "lineage_" ""
    replace_value_resetprop ro.\${prefix}.build.fingerprint "lineage_" ""
    replace_value_resetprop ro.product.\${prefix}.name "lineage_" ""
done

EOF

    # copy ke modul
    cp -f "$FILE_FS" "$XKAT_FS" > /dev/null 2>&1; 
    cp -f "$FILE_FS" "$MHPC_FS" > /dev/null 2>&1; 

}